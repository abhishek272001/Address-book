<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Address Book Entry</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="container">
        <h1>Create Address Book Entry</h1>
        
        <form method="POST" action="{{ route('address-book.store') }}" enctype="multipart/form-data">
            @csrf
            <input type="text" name="first_name" placeholder="First Name" required />
            <input type="text" name="last_name" placeholder="Last Name" required />
            <input type="email" name="email" placeholder="Email" id="email" required />
            <span id="email-validation"></span>
            <input type="text" name="phone" placeholder="Phone (10 digits)" required pattern="\d{10}" />
            <input type="text" name="street" placeholder="Street" required />
            <input type="text" name="zip_code" placeholder="Zip Code" required />
            <select name="city" required>
                <option value="">Select City</option>
                @foreach($cities as $city)
                    <option value="{{ $city->name }}">{{ $city->name }}</option>
                @endforeach
            </select>
            <input type="file" name="profile_pic" accept="image/*" />
            <button type="submit">Save</button>
        </form>
    </div>

    <script>
        document.getElementById("email").addEventListener("input", function () {
            let email = this.value;
            let validationMessage = document.getElementById("email-validation");

            if (email) {
                fetch('/check-email?email=' + email)
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            validationMessage.textContent = "Email already exists!";
                            validationMessage.style.color = 'red';
                        } else {
                            validationMessage.textContent = "Email is available!";
                            validationMessage.style.color = 'green';
                        }
                    });
            } else {
                validationMessage.textContent = '';
            }
        });
    </script>
</body>
</html>
