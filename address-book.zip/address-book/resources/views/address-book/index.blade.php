<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Address Book</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="container">
        <h1>Address Book Entries</h1>

        <a href="{{ route('address-book.create') }}">Add New Entry</a>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <table border="1">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Street</th>
                    <th>Zip Code</th>
                    <th>City</th>
                    <th>Profile Pic</th>
                </tr>
            </thead>
            <tbody>
            @forelse ($entries as $entry)
                <tr>
                    <td>{{ $entry->first_name }}</td>
                    <td>{{ $entry->last_name }}</td>
                    <td>{{ $entry->email }}</td>
                    <td>{{ $entry->phone }}</td>
                    <td>{{ $entry->street }}</td>
                    <td>{{ $entry->zip_code }}</td>
                    <td>{{ $entry->city }}</td>
                    <td>
                        @if ($entry->profile_pic)
                            <img src="{{ asset('storage/' . $entry->profile_pic) }}" alt="Profile Pic" width="50" />
                        @else
                            N/A
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('address-book.edit', $entry->slug) }}">Edit</a>
                        <form action="{{ route('address-book.destroy', $entry->slug) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this entry?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="9">No entries found.</td>
                </tr>
            @endforelse
        </tbody>
        </table>
    </div>
</body>
</html>
