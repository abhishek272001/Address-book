<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Address Book Entry</title>
</head>
<body>
    <div class="container">
        <h1>Edit Address Book Entry</h1>

        <form action="{{ route('address-book.update', $entry->slug) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <input type="text" name="first_name" value="{{ $entry->first_name }}" required />
            <input type="text" name="last_name" value="{{ $entry->last_name }}" required />
            <input type="email" name="email" value="{{ $entry->email }}" required />
            <input type="text" name="phone" value="{{ $entry->phone }}" required />
            <input type="text" name="street" value="{{ $entry->street }}" required />
            <input type="text" name="zip_code" value="{{ $entry->zip_code }}" required />
            <select name="city" required>
                @foreach ($cities as $city)
                    <option value="{{ $city->name }}" {{ $entry->city == $city->name ? 'selected' : '' }}>
                        {{ $city->name }}
                    </option>
                @endforeach
            </select>
            <input type="file" name="profile_pic" accept="image/*" />
            @if ($entry->profile_pic)
                <img src="{{ asset('storage/' . $entry->profile_pic) }}" alt="Profile Pic" width="50" />
            @endif

            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
