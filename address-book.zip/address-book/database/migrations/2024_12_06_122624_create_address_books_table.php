<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('address_books', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->string('phone', 10);
            $table->string('street');
            $table->string('zip_code');
            $table->string('city');
            $table->string('profile_pic')->nullable();
            $table->text('description')->nullable(); 
            $table->timestamps();
        });
        
        // Migration for cities
        Schema::create('cities', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
        });
        
        // Migration for logs
        Schema::create('logs', function (Blueprint $table) {
            $table->id();
            $table->string('action');
            $table->text('description');
            $table->timestamps();
        });        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('address_books');
    }
};
