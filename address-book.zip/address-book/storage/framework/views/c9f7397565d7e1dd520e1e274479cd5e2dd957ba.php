<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Address Book Entry</title>
</head>
<body>
    <div class="container">
        <h1>Edit Address Book Entry</h1>

        <form action="<?php echo e(route('address-book.update', $entry->slug)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <input type="text" name="first_name" value="<?php echo e($entry->first_name); ?>" required />
            <input type="text" name="last_name" value="<?php echo e($entry->last_name); ?>" required />
            <input type="email" name="email" value="<?php echo e($entry->email); ?>" required />
            <input type="text" name="phone" value="<?php echo e($entry->phone); ?>" required />
            <input type="text" name="street" value="<?php echo e($entry->street); ?>" required />
            <input type="text" name="zip_code" value="<?php echo e($entry->zip_code); ?>" required />
            <select name="city" required>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->name); ?>" <?php echo e($entry->city == $city->name ? 'selected' : ''); ?>>
                        <?php echo e($city->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="file" name="profile_pic" accept="image/*" />
            <?php if($entry->profile_pic): ?>
                <img src="<?php echo e(asset('storage/' . $entry->profile_pic)); ?>" alt="Profile Pic" width="50" />
            <?php endif; ?>

            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\task\address-book\resources\views/address-book/edit.blade.php ENDPATH**/ ?>