<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Address Book</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Address Book Entries</h1>

        <a href="<?php echo e(route('address-book.create')); ?>">Add New Entry</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <table border="1">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Street</th>
                    <th>Zip Code</th>
                    <th>City</th>
                    <th>Profile Pic</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($entry->first_name); ?></td>
                    <td><?php echo e($entry->last_name); ?></td>
                    <td><?php echo e($entry->email); ?></td>
                    <td><?php echo e($entry->phone); ?></td>
                    <td><?php echo e($entry->street); ?></td>
                    <td><?php echo e($entry->zip_code); ?></td>
                    <td><?php echo e($entry->city); ?></td>
                    <td>
                        <?php if($entry->profile_pic): ?>
                            <img src="<?php echo e(asset('storage/' . $entry->profile_pic)); ?>" alt="Profile Pic" width="50" />
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('address-book.edit', $entry->slug)); ?>">Edit</a>
                        <form action="<?php echo e(route('address-book.destroy', $entry->slug)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this entry?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9">No entries found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\task\address-book\resources\views/address-book/index.blade.php ENDPATH**/ ?>