<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AddressBookController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


// Route for checking email availability
Route::get('/check-email', [AddressBookController::class, 'checkEmail']);

// Address book routes
Route::get('/address-book', [AddressBookController::class, 'index'])->name('address-book.index');
Route::get('/address-book/create', [AddressBookController::class, 'create'])->name('address-book.create');
Route::post('/address-book', [AddressBookController::class, 'store'])->name('address-book.store');
Route::get('/address-book/{slug}/edit', [AddressBookController::class, 'edit'])->name('address-book.edit');
Route::put('/address-book/{slug}', [AddressBookController::class, 'update'])->name('address-book.update');
Route::delete('/address-book/{slug}', [AddressBookController::class, 'destroy'])->name('address-book.destroy');




