<?php

namespace App\Http\Controllers;

use App\Models\AddressBook;
use App\Models\City;
use App\Models\Log;
use App\Jobs\SendPromotionalEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;
use Carbon\Carbon;

class AddressBookController extends Controller
{
    // Display a listing of address book entries with caching
    public function index()
    {
        $entries = Cache::remember('address_book_entries', 60, function () {
            return AddressBook::orderBy('first_name')->get();
        });
        return view('address-book.index', compact('entries'));
    }

    // Show the form for creating a new entry
    public function create()
    {
        $cities = City::all();
        return view('address-book.create', compact('cities'));
    }

    // Real-time email validation
    public function checkEmail(Request $request)
    {
        $exists = AddressBook::where('email', $request->email)->exists();
        return response()->json(['exists' => $exists]);
    }

    // Store a new address book entry
    public function store(Request $request)
    {
        // Validate the request
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:address_books,email',
            'phone' => 'required|digits:10',
            'street' => 'required|string|max:255',
            'zip_code' => 'required|string|max:10',
            'city' => 'required|exists:cities,name',
            'profile_pic' => 'nullable|image|mimes:jpg,jpeg,png,gif,svg,webp|max:300|dimensions:width=150,height=150',
            'description' => 'nullable|string|max:1000',
        ]);

        // Handle image upload
        $filePath = null;
        if ($request->hasFile('profile_pic')) {
            $image = $request->file('profile_pic');
            $filePath = $image->storeAs('profile_pics', uniqid() . '.' . $image->getClientOriginalExtension(), 'public');
        }

        // Create the entry and generate a unique slug
        $entry = AddressBook::create(array_merge($request->all(), [
            'profile_pic' => $filePath,
            'slug' => uniqid(),
        ]));

        // Log the action
        Log::create([
            'action' => 'insert',
            'data' => json_encode($entry->toArray()),
        ]);

        // Send email immediately after creation
        Mail::raw('Welcome to our address book!', function ($message) use ($entry) {
            $message->to($entry->email)
                ->subject('Address Book Entry Added');
        });

        // Queue a promotional email for one hour later
        SendPromotionalEmail::dispatch($entry->email)
            ->delay(Carbon::now()->addHour());

        return redirect()->route('address-book.index')->with('success', 'Entry added successfully!');
    }

    // Show the form for editing an entry
    public function edit($slug)
    {
        $entry = AddressBook::where('slug', $slug)->firstOrFail();
        $cities = City::all();
        return view('address-book.edit', compact('entry', 'cities'));
    }

    // Update an existing address book entry
    public function update(Request $request, $slug)
    {
        $entry = AddressBook::where('slug', $slug)->firstOrFail();

        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:address_books,email,' . $entry->id,
            'phone' => 'required|digits:10',
            'street' => 'required|string|max:255',
            'zip_code' => 'required|string|max:10',
            'city' => 'required|exists:cities,name',
            'profile_pic' => 'nullable|image|mimes:jpg,jpeg,png,gif,svg,webp|max:300|dimensions:width=150,height=150',
            'description' => 'nullable|string|max:1000',
        ]);

        // Handle image upload if exists
        if ($request->hasFile('profile_pic')) {
            if ($entry->profile_pic) {
                Storage::disk('public')->delete($entry->profile_pic);
            }
            $image = $request->file('profile_pic');
            $filePath = $image->storeAs('profile_pics', uniqid() . '.' . $image->getClientOriginalExtension(), 'public');
            $entry->profile_pic = $filePath;
        }

        // Update the entry
        $entry->update($request->all());

        // Log the update action
        Log::create([
            'action' => 'update',
            'data' => json_encode($entry->toArray()),
        ]);

        return redirect()->route('address-book.index')->with('success', 'Entry updated successfully!');
    }

    // Delete an entry from the address book
    public function destroy($slug)
    {
        $entry = AddressBook::where('slug', $slug)->firstOrFail();

        if ($entry->profile_pic) {
            Storage::disk('public')->delete($entry->profile_pic);
        }

        // Log the delete action
        Log::create([
            'action' => 'delete',
            'data' => json_encode($entry->toArray()),
        ]);

        $entry->delete();

        return redirect()->route('address-book.index')->with('success', 'Entry deleted successfully!');
    }
}
