<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddressBook extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'slug', 'first_name', 'last_name', 'email', 'phone', 
        'street', 'zip_code', 'city', 'profile_pic'
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->slug = uniqid(); // Generate unique slug
        });

        static::created(function ($model) {
            // Log creation
            Log::create([
                'action' => 'Create',
                'description' => "New record created: {$model->first_name} {$model->last_name}"
            ]);
        });

        static::updating(function ($model) {
            // Log update
            Log::create([
                'action' => 'Update',
                'description' => "Record updated: {$model->first_name} {$model->last_name}"
            ]);
        });

        static::deleting(function ($model) {
            // Log delete
            Log::create([
                'action' => 'Delete',
                'description' => "Record deleted: {$model->first_name} {$model->last_name}"
            ]);
        });
    }
}
