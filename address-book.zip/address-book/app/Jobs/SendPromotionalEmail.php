<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Mail;

class SendPromotionalEmail implements ShouldQueue
{
    use Dispatchable, Queueable;

    public $email;

    public function __construct($email)
    {
        $this->email = $email;
    }

    public function handle()
    {
        Mail::raw('Promotional email content', function ($message) {
            $message->to($this->email)->subject('Promotional Offer');
        });
    }
}

